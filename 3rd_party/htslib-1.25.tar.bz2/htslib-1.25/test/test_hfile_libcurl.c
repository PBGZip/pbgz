/*  test/test_hfile_libcurl.c -- Test cases for libcurl retry/resilience.

    Copyright (C) 2026 Broad Institute.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.  */

#include <config.h>

#include <stdio.h>
#include <stdlib.h>

// This test requires fork/pipe/kill which are POSIX-only.
#ifdef _WIN32
int main(void) {
    fprintf(stderr, "libcurl retry tests not supported on Windows, skipping\n");
    return 0;
}
#else

#include <string.h>
#include <errno.h>
#include <signal.h>
#include <unistd.h>
#include <sys/wait.h>

#include "../htslib/hfile.h"
#include "../htslib/hts.h"
#include "../hts_internal.h"

#ifndef EPROTONOSUPPORT
#define EPROTONOSUPPORT ENOSYS
#endif

// Test data file to serve
#define TEST_DATA_FILE "hfile_libcurl.tmp"
#define TEST_DATA_SIZE 16384

static int failures = 0;

#define PASS(name) fprintf(stderr, "  PASS: %s\n", (name))
#define FAIL(name, ...) do { \
    fprintf(stderr, "  FAIL: %s: ", (name)); \
    fprintf(stderr, __VA_ARGS__); \
    fprintf(stderr, "\n"); \
    failures++; \
} while (0)

// Start mock server serving file, return its PID and port
static pid_t start_server_file(const char *mode, const char *file,
                               int fail_count, int *port_out)
{
    int pipefd[2];
    pid_t pid;
    char fail_count_str[32];
    char port_buf[32];
    ssize_t n;
    int i;

    if (pipe(pipefd) < 0) {
        perror("pipe");
        return -1;
    }

    snprintf(fail_count_str, sizeof(fail_count_str), "%d", fail_count);

    pid = fork();
    if (pid < 0) {
        perror("fork");
        close(pipefd[0]);
        close(pipefd[1]);
        return -1;
    }

    if (pid == 0) {
        // Child: redirect stdout to pipe, exec python server
        close(pipefd[0]);
        dup2(pipefd[1], STDOUT_FILENO);
        close(pipefd[1]);
        execlp("python3", "python3", "test/mock_http_server.py",
               "--mode", mode,
               "--file", file,
               "--fail-count", fail_count_str,
               "--port", "0",
               NULL);
        perror("execlp python3");
        _exit(127);
    }

    // Parent: read port from pipe
    close(pipefd[1]);

    // Read with timeout (give server up to 5 seconds to start)
    n = 0;
    for (i = 0; i < 50 && n == 0; i++) {
        n = read(pipefd[0], port_buf, sizeof(port_buf) - 1);
        if (n <= 0) {
            hts_usleep(100000); // 100ms
            n = 0;
        }
    }
    close(pipefd[0]);

    if (n <= 0) {
        fprintf(stderr, "Failed to read port from mock server\n");
        kill(pid, SIGTERM);
        waitpid(pid, NULL, 0);
        return -1;
    }

    port_buf[n] = '\0';
    *port_out = atoi(port_buf);
    if (*port_out <= 0) {
        fprintf(stderr, "Invalid port from mock server: %s\n", port_buf);
        kill(pid, SIGTERM);
        waitpid(pid, NULL, 0);
        return -1;
    }

    // Give the server a moment to be ready for connections
    hts_usleep(100000);
    return pid;
}

static pid_t start_server(const char *mode, int fail_count, int *port_out)
{
    return start_server_file(mode, "test/" TEST_DATA_FILE, fail_count, port_out);
}

static void stop_server(pid_t pid)
{
    int status;
    pid_t ret;

    if (pid <= 0)
        return;

    kill(pid, SIGKILL);
    ret = waitpid(pid, &status, 0);
    if (ret < 0)
        perror("waitpid");
}

// Generate deterministic test data
static void generate_test_data(void)
{
    FILE *f;
    int i;
    char path[256];

    snprintf(path, sizeof(path), "test/%s", TEST_DATA_FILE);
    f = fopen(path, "wb");
    if (!f) {
        perror("fopen test data");
        exit(EXIT_FAILURE);
    }
    for (i = 0; i < TEST_DATA_SIZE; i++) {
        fputc((i * 7 + 13) & 0xFF, f);
    }
    fclose(f);
}

// Read expected data from test file
static unsigned char *read_expected_data(size_t *size_out)
{
    FILE *f;
    unsigned char *data;
    char path[256];

    snprintf(path, sizeof(path), "test/%s", TEST_DATA_FILE);
    f = fopen(path, "rb");
    if (!f) {
        perror("fopen expected data");
        return NULL;
    }
    data = malloc(TEST_DATA_SIZE);
    if (!data) {
        fclose(f);
        return NULL;
    }
    *size_out = fread(data, 1, TEST_DATA_SIZE, f);
    fclose(f);
    return data;
}

// Read entire file via hFILE
static unsigned char *hfile_read_all(const char *url, size_t *size_out)
{
    hFILE *fp;
    unsigned char *buf;
    size_t total = 0;
    ssize_t n;

    fp = hopen(url, "r");
    if (!fp)
        return NULL;

    buf = malloc(TEST_DATA_SIZE + 1024);
    if (!buf) {
        hclose_abruptly(fp);
        return NULL;
    }

    while ((n = hread(fp, buf + total, 4096)) > 0) {
        total += n;
        if (total > TEST_DATA_SIZE + 512)
            break;
    }

    if (n < 0) {
        free(buf);
        hclose_abruptly(fp);
        *size_out = 0;
        return NULL;
    }

    if (hclose(fp) != 0)
        perror("hclose");
    *size_out = total;
    return buf;
}

// Test 1: Normal transfer
static void test_normal_transfer(void)
{
    const char *name = "Normal transfer";
    pid_t pid;
    int port;
    char url[256];
    unsigned char *got, *expected;
    size_t got_size, exp_size;

    pid = start_server("normal", 0, &port);
    if (pid < 0) { FAIL(name, "could not start server"); return; }

    snprintf(url, sizeof(url), "http://127.0.0.1:%d/data", port);
    got = hfile_read_all(url, &got_size);
    expected = read_expected_data(&exp_size);

    if (!got) {
        FAIL(name, "hfile_read_all returned NULL, errno=%d", errno);
    } else if (got_size != exp_size) {
        FAIL(name, "size mismatch: got %zu, expected %zu", got_size, exp_size);
    } else if (memcmp(got, expected, exp_size) != 0) {
        FAIL(name, "data mismatch");
    } else {
        PASS(name);
    }

    free(got);
    free(expected);
    stop_server(pid);
}

// Test 2: 503 retry succeeds
static void test_503_retry(void)
{
    const char *name = "503 retry succeeds";
    pid_t pid;
    int port;
    char url[256];
    unsigned char *got, *expected;
    size_t got_size, exp_size;

    pid = start_server("503_then_ok", 2, &port);
    if (pid < 0) { FAIL(name, "could not start server"); return; }

    snprintf(url, sizeof(url), "http://127.0.0.1:%d/data", port);
    setenv("HTS_RETRY_MAX", "3", 1);
    setenv("HTS_RETRY_DELAY", "50", 1);

    got = hfile_read_all(url, &got_size);
    expected = read_expected_data(&exp_size);

    if (!got) {
        FAIL(name, "hfile_read_all returned NULL, errno=%d", errno);
    } else if (got_size != exp_size) {
        FAIL(name, "size mismatch: got %zu, expected %zu", got_size, exp_size);
    } else if (memcmp(got, expected, exp_size) != 0) {
        FAIL(name, "data mismatch");
    } else {
        PASS(name);
    }

    free(got);
    free(expected);
    unsetenv("HTS_RETRY_MAX");
    unsetenv("HTS_RETRY_DELAY");
    stop_server(pid);
}

// Test 3: 429 retry succeeds
static void test_429_retry(void)
{
    const char *name = "429 retry succeeds";
    pid_t pid;
    int port;
    char url[256];
    unsigned char *got, *expected;
    size_t got_size, exp_size;

    pid = start_server("429_then_ok", 2, &port);
    if (pid < 0) { FAIL(name, "could not start server"); return; }

    snprintf(url, sizeof(url), "http://127.0.0.1:%d/data", port);
    setenv("HTS_RETRY_MAX", "3", 1);
    setenv("HTS_RETRY_DELAY", "50", 1);

    got = hfile_read_all(url, &got_size);
    expected = read_expected_data(&exp_size);

    if (!got) {
        FAIL(name, "hfile_read_all returned NULL, errno=%d", errno);
    } else if (got_size != exp_size) {
        FAIL(name, "size mismatch: got %zu, expected %zu", got_size, exp_size);
    } else if (memcmp(got, expected, exp_size) != 0) {
        FAIL(name, "data mismatch");
    } else {
        PASS(name);
    }

    free(got);
    free(expected);
    unsetenv("HTS_RETRY_MAX");
    unsetenv("HTS_RETRY_DELAY");
    stop_server(pid);
}

// Test 4: Connection drop retry
static void test_drop_mid_transfer(void)
{
    const char *name = "Connection drop retry";
    pid_t pid;
    int port;
    char url[256];
    unsigned char *got, *expected;
    size_t got_size, exp_size;

    pid = start_server("drop_mid_transfer", 2, &port);
    if (pid < 0) { FAIL(name, "could not start server"); return; }

    snprintf(url, sizeof(url), "http://127.0.0.1:%d/data", port);
    setenv("HTS_RETRY_MAX", "5", 1);
    setenv("HTS_RETRY_DELAY", "50", 1);

    got = hfile_read_all(url, &got_size);
    expected = read_expected_data(&exp_size);

    if (!got) {
        FAIL(name, "hfile_read_all returned NULL, errno=%d", errno);
    } else if (got_size != exp_size) {
        FAIL(name, "size mismatch: got %zu, expected %zu", got_size, exp_size);
    } else if (memcmp(got, expected, exp_size) != 0) {
        FAIL(name, "data mismatch");
    } else {
        PASS(name);
    }

    free(got);
    free(expected);
    unsetenv("HTS_RETRY_MAX");
    unsetenv("HTS_RETRY_DELAY");
    stop_server(pid);
}

// Test 5: 404 not retried
static void test_404_no_retry(void)
{
    const char *name = "404 not retried";
    pid_t pid;
    int port;
    char url[256];
    hFILE *fp;

    pid = start_server("404", 0, &port);
    if (pid < 0) { FAIL(name, "could not start server"); return; }

    snprintf(url, sizeof(url), "http://127.0.0.1:%d/data", port);
    setenv("HTS_RETRY_MAX", "3", 1);
    setenv("HTS_RETRY_DELAY", "50", 1);

    fp = hopen(url, "r");
    if (fp != NULL) {
        FAIL(name, "hopen should have failed for 404");
        hclose_abruptly(fp);
    } else if (errno != ENOENT) {
        FAIL(name, "expected ENOENT, got errno=%d (%s)", errno, strerror(errno));
    } else {
        PASS(name);
    }

    unsetenv("HTS_RETRY_MAX");
    unsetenv("HTS_RETRY_DELAY");
    stop_server(pid);
}

// Test 6: Retry exhaustion
static void test_retry_exhaustion(void)
{
    const char *name = "Retry exhaustion";
    pid_t pid;
    int port;
    char url[256];
    hFILE *fp;

    pid = start_server("503_then_ok", 999, &port);
    if (pid < 0) { FAIL(name, "could not start server"); return; }

    snprintf(url, sizeof(url), "http://127.0.0.1:%d/data", port);
    setenv("HTS_RETRY_MAX", "2", 1);
    setenv("HTS_RETRY_DELAY", "50", 1);

    fp = hopen(url, "r");
    if (fp != NULL) {
        FAIL(name, "hopen should have failed after retry exhaustion");
        hclose_abruptly(fp);
    } else {
        PASS(name);
    }

    unsetenv("HTS_RETRY_MAX");
    unsetenv("HTS_RETRY_DELAY");
    stop_server(pid);
}

// Test 7: Retry disabled
static void test_retry_disabled(void)
{
    const char *name = "Retry disabled";
    pid_t pid;
    int port;
    char url[256];
    hFILE *fp;

    pid = start_server("503_then_ok", 1, &port);
    if (pid < 0) { FAIL(name, "could not start server"); return; }

    snprintf(url, sizeof(url), "http://127.0.0.1:%d/data", port);
    setenv("HTS_RETRY_MAX", "0", 1);
    setenv("HTS_RETRY_DELAY", "50", 1);

    fp = hopen(url, "r");
    if (fp != NULL) {
        FAIL(name, "hopen should have failed with retries disabled");
        hclose_abruptly(fp);
    } else {
        PASS(name);
    }

    unsetenv("HTS_RETRY_MAX");
    unsetenv("HTS_RETRY_DELAY");
    stop_server(pid);
}

// Test 8: hfile_s3 reading to EOF when the file size is a multiple of the
// read part size, so the last part is full-sized (issue #2097)
static void test_s3_eof_at_part_boundary(void)
{
    const char *name = "S3 read to EOF at a part boundary";
    const char *file = "test/hfile_s3_eof.tmp";
    const size_t size = 1024 * 1024; // the default S3 read part size
    char host[64], buf[4096];
    size_t i, total = 0;
    ssize_t n = 0;
    int port;
    pid_t pid;
    hFILE *fp;
    FILE *f;

    f = fopen(file, "wb");
    if (!f) { FAIL(name, "could not write %s", file); return; }
    for (i = 0; i < size; i++)
        fputc((i * 7 + 13) & 0xFF, f);
    fclose(f);

    pid = start_server_file("s3", file, 0, &port);
    if (pid < 0) { FAIL(name, "could not start server"); unlink(file); return; }

    snprintf(host, sizeof(host), "127.0.0.1:%d", port);
    setenv("HTS_S3_HOST", host, 1);
    setenv("HTS_S3_ADDRESS_STYLE", "path", 1);
    setenv("AWS_ACCESS_KEY_ID", "test", 1);
    setenv("AWS_SECRET_ACCESS_KEY", "test", 1);
    setenv("HTS_ALLOW_UNENCRYPTED_AUTHORIZATION_HEADER", "I understand the risks", 1);

    fp = hopen("s3+http://bucket/object", "r");
    if (!fp) {
        if (errno == EPROTONOSUPPORT)
            fprintf(stderr, "  SKIP: %s: S3 not supported\n", name);
        else
            FAIL(name, "hopen failed: %s", strerror(errno));
    } else {
        while ((n = hread(fp, buf, sizeof(buf))) > 0)
            total += n;
        if (n < 0)
            FAIL(name, "hread failed after %zu bytes: %s", total, strerror(errno));
        else if (total != size)
            FAIL(name, "read %zu bytes, expected %zu", total, size);
        else if (hseek(fp, size, SEEK_SET) < 0 || (n = hread(fp, buf, sizeof(buf))) != 0)
            FAIL(name, "read after seeking to EOF returned %zd: %s", n, strerror(errno));
        else
            PASS(name);
        hclose_abruptly(fp);
    }

    unsetenv("HTS_S3_HOST");
    unsetenv("HTS_S3_ADDRESS_STYLE");
    unsetenv("AWS_ACCESS_KEY_ID");
    unsetenv("AWS_SECRET_ACCESS_KEY");
    unsetenv("HTS_ALLOW_UNENCRYPTED_AUTHORIZATION_HEADER");
    stop_server(pid);
    unlink(file);
}

int main(void)
{
    // Check python3 is available
    if (system("python3 --version >/dev/null 2>&1") != 0) {
        fprintf(stderr, "python3 not found, skipping libcurl retry tests\n");
        return 0; // Skip rather than fail
    }

    // Check that HTTP URLs are supported (i.e. libcurl backend is loaded).
    // Try opening a URL that will fail to connect — if errno is
    // EPROTONOSUPPORT the http:// scheme isn't registered.
    {
        hFILE *probe;
        setenv("HTS_RETRY_MAX", "0", 1);
        probe = hopen("http://0.0.0.0:1/probe", "r");
        unsetenv("HTS_RETRY_MAX");
        if (probe) {
            hclose_abruptly(probe);
        } else if (errno == EPROTONOSUPPORT) {
            fprintf(stderr, "HTTP not supported, skipping libcurl retry tests\n");
            return 0;
        }
        // ECONNREFUSED or similar means libcurl is working, continue
    }

    generate_test_data();

    fprintf(stderr, "test_hfile_libcurl:\n");

    test_normal_transfer();
    test_503_retry();
    test_429_retry();
    test_drop_mid_transfer();
    test_404_no_retry();
    test_retry_exhaustion();
    test_retry_disabled();
    test_s3_eof_at_part_boundary();

    // Clean up test data
    unlink("test/" TEST_DATA_FILE);

    if (failures > 0) {
        fprintf(stderr, "%d test(s) FAILED\n", failures);
        return EXIT_FAILURE;
    }

    fprintf(stderr, "All tests passed.\n");
    return EXIT_SUCCESS;
}

#endif /* !_WIN32 */
